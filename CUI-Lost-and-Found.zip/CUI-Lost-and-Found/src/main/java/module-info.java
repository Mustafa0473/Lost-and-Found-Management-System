module org.example.cuilostandfound {
    requires javafx.controls;
    requires javafx.fxml;
    requires opencv;


    opens org.example.cuilostandfound to javafx.fxml;
    exports org.example.cuilostandfound;
}