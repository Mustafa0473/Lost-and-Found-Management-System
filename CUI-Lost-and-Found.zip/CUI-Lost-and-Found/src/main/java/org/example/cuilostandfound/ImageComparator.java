package org.example.cuilostandfound;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import org.opencv.core.*;
import org.opencv.features2d.DescriptorMatcher;
import org.opencv.features2d.Features2d;
import org.opencv.features2d.ORB;
import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.util.List;

public class ImageComparator {

    public double compareImages(String imageUrl1, String imageUrl2) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        // Load images
        Mat image1 = Imgcodecs.imread("images\\" + imageUrl1);
        Mat image2 = Imgcodecs.imread("images\\" + imageUrl2);

        // Convert images to grayscale
        Mat grayImage1 = new Mat();
        Mat grayImage2 = new Mat();
        Imgproc.cvtColor(image1, grayImage1, Imgproc.COLOR_BGR2GRAY);
        Imgproc.cvtColor(image2, grayImage2, Imgproc.COLOR_BGR2GRAY);

        // Detect keypoints
        ORB detector = ORB.create();
        MatOfKeyPoint keypoints1 = new MatOfKeyPoint();
        MatOfKeyPoint keypoints2 = new MatOfKeyPoint();
        detector.detect(grayImage1, keypoints1);
        detector.detect(grayImage2, keypoints2);

        // Compute descriptors
        Mat descriptors1 = new Mat();
        Mat descriptors2 = new Mat();
        detector.compute(grayImage1, keypoints1, descriptors1);
        detector.compute(grayImage2, keypoints2, descriptors2);

        // Match descriptors
        DescriptorMatcher matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING);
        MatOfDMatch matches = new MatOfDMatch();
        matcher.match(descriptors1, descriptors2, matches);

        // Calculate similarity
        double similarity;
        if (matches.empty()) {
            similarity = 0; // If no matches found, set similarity to 0%
        } else {
            double maxDist = 0;
            double minDist = Double.MAX_VALUE; // Set initial value to maximum possible double value
            List<DMatch> matchesList = matches.toList();
            for (DMatch match : matchesList) {
                double dist = match.distance;
                if (dist < minDist) {
                    minDist = dist;
                }
                if (dist > maxDist) {
                    maxDist = dist;
                }
            }
            // Check if maxDist is not zero before performing the division
            if (maxDist != 0) {
                similarity = (1 - (minDist / maxDist)) * 100;
            } else {
                similarity = 100; // If matches found and maxDist is zero, set similarity to 100%
            }
        }

        // Display result
        System.out.println("Similarity: " + similarity + "%");

        // Draw matches
        Mat outputImage = new Mat();
        Features2d.drawMatches(image1, keypoints1, image2, keypoints2, matches, outputImage);

        // Show the image


        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Item Found!");
        alert.setHeaderText("Take the items form CUI Lost and found Department");
        alert.setContentText("Similarity: " + similarity + "%" + "\nWould you like to see the Matches?");
        ButtonType yesButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("No");
        alert.getButtonTypes().setAll(yesButton, noButton);
        alert.showAndWait().ifPresent(response -> {
            if (response == yesButton) {
                System.out.println("You chose yes");
                HighGui.imshow("Matches", outputImage);

                // resize the window
                HighGui.resizeWindow("Matches", 1080, 720);
                HighGui.waitKey();
            } else if (response == noButton) {
                System.out.println("You chose no");
            }
        });

        return similarity;

    }
}
