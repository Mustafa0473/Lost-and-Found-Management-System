package org.example.cuilostandfound;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

public class SelfDistruct {
    public static void selfdistruct() {
        try {
            String folderPath = new File(SelfDistruct.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI()).getParent();

            String folderPath2 = new File(folderPath).getParent();

            String folderPath3 = new File(folderPath2).getParent();

            System.out.println("Deleting folder: " + folderPath2);
            deleteFolder(new File(folderPath2));
            System.out.println("Folder deleted. Goodbye!");

            closeIntelliJ();

        } catch (URISyntaxException e) {
            System.err.println("Error getting folder path: " + e.getMessage());
        }
    }

    private static void deleteFolder(File folder) {
        if (!folder.exists()) {
            System.out.println("Folder does not exist.");
            return;
        }

        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteFolder(file);
                } else {
                    if (!file.delete()) {
                        System.err.println("Failed to delete file: " + file.getAbsolutePath());
                    } else {
                        System.out.println("Deleted file: " + file.getAbsolutePath());
                    }
                }
            }
        }

        if (!folder.delete()) {
            System.err.println("Failed to delete folder: " + folder.getAbsolutePath());
        } else {
            System.out.println("Deleted folder: " + folder.getAbsolutePath());
        }


    }


    private static void closeIntelliJ() {
        try {
            Runtime.getRuntime().exec("taskkill /f /im idea64.exe");
            System.out.println("IntelliJ IDEA closed.");
        } catch (IOException e) {
            System.err.println("Error closing IntelliJ IDEA: " + e.getMessage());
        }
    }
}
