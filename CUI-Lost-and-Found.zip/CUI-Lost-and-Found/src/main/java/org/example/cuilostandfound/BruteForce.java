package org.example.cuilostandfound;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class BruteForce {

    private static String generateAttempt(char[] chars, int length, int index) {
        StringBuilder attempt = new StringBuilder();
        int[] indices = new int[length];
        for (int i = 0; i < length; i++) {
            indices[i] = index % chars.length;
            index /= chars.length;
        }
        for (int i = indices.length - 1; i >= 0; i--) {
            attempt.append(chars[indices[i]]);
        }
        return attempt.toString();
    }

    public static void bruteForce(Service service, Stage stage, Button backButton) {


        Text title = new Text("Brute Force");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("red"));


        VBox layout = new VBox(20, title);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        System.out.println("brute force");
        char[] chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".toCharArray();

        // Create a label

        Label label = new Label("Enter Student ID");
        TextField tf_student_id = new TextField();

        label.setFont(Font.font("Arial", FontWeight.BOLD, 16));

        // Create a button
        Button bruteForcebutton = new Button("Start BruteForce");
        styleButton(bruteForcebutton);

        layout.getChildren().addAll(label, tf_student_id);

        HBox btns = new HBox(backButton, bruteForcebutton);
        btns.setAlignment(Pos.CENTER);
        btns.setSpacing(5);

        layout.getChildren().add(btns);

        VBox whiteBox = new VBox(20, layout);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);

        bruteForcebutton.setOnAction(event -> {


            String student_id = tf_student_id.getText();
            String password = service.getStudentPassword(Encryption.encrypt(student_id));


            int attempts = 0;
            boolean cracked = false;
            int length = 1;
            while (!cracked) {
                for (int i = 0; i < Math.pow(chars.length, length); i++) {
                    Label newLabel = new Label();

                    String attempt = generateAttempt(chars, length, i);
                    attempts++;
                    if (attempt.equals(password)) { // Replace "password" with the actual password
                        cracked = true;
                        System.out.println("Password Cracked: " + attempt + " (Attempts: " + attempts + ")");
                        newLabel.setText("Password Cracked: " + attempt + " (Attempts: " + attempts + ")");
                        newLabel.setTextFill(Color.GREEN);
                        newLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
                    } else {
                        System.out.println("Attempt " + attempts + ": " + attempt + " (Failed)");
                        newLabel.setText("Attempt " + attempts + ": " + attempt + " (Failed)");
                        newLabel.setTextFill(Color.RED);
                    }
                    layout.getChildren().add(newLabel);
                    if (layout.getChildren().size() > 5) {
                        String a = String.valueOf(layout.getChildren().get(0));
                        Label oldestLabel = new Label(a);
                        oldestLabel.setOpacity(0);
                        layout.getChildren().remove(0);
                    }
                    if (cracked) {
                        layout.getChildren().add(backButton);
                        break;
                    }
                }
                if (!cracked) {
                    length++;
                    System.out.println("Increasing length to " + length);
                    label.setText("Increasing length to " + length);
                }
            }


        });
    }

    private static void styleButton(Button button) {
        button.setStyle(
                "-fx-background-color: #2980b9; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 18px; " +
                        "-fx-font-weight: bold; " +
                        "-fx-padding: 10 20 10 20; " +
                        "-fx-background-radius: 5; " +
                        "-fx-cursor: hand; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);"
        );

        button.setOnMouseEntered(e -> button.setStyle(
                "-fx-background-color: #3498db; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 18px; " +
                        "-fx-font-weight: bold; " +
                        "-fx-padding: 10 20 10 20; " +
                        "-fx-background-radius: 5; " +
                        "-fx-cursor: hand; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);"
        ));

        button.setOnMouseExited(e -> button.setStyle(
                "-fx-background-color: #2980b9; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 18px; " +
                        "-fx-font-weight: bold; " +
                        "-fx-padding: 10 20 10 20; " +
                        "-fx-background-radius: 5; " +
                        "-fx-cursor: hand; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);"
        ));
    }
}
