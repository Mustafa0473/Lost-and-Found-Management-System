// Bismillah-i-Rahmaan-i-Raheem

package org.example.cuilostandfound;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public class MainFx extends Application {


    // Variables
    String student_id = "";
    String student_password = "";
    String student_new_password = "";
    String student_name = "";
    String student_age = "";
    String student_gender = "";
    String student_semester = "";
    String item_name = "";
    String item_image = "";
    String item_category = "";
    String item_color = "";
    String item_location = "";
    String item_description = "";
    String admin_id = "";
    String admin_password = "";

    Hacker hacker = new Hacker();
    Service service = new Service();
    private Stage primaryStage;


    @Override
    public void start(Stage stage) throws IOException {
        this.primaryStage = stage;
        primaryStage.setTitle("CUI LOST AND FOUND");


        // Show main menu
        showMainMenu();
    }


    private void showMainMenu() {
        // Load the logo image
        String logoPath = Paths.get("images/Comsats_logo.png").toUri().toString();
        Image logoImage = new Image(logoPath);
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitWidth(300); // Adjust the width to fit your layout
        logoImageView.setFitHeight(90); // Adjust the height to fit your layout

        // Load the background image
        String backgroundPath = Paths.get("images/comsats.jpg").toUri().toString(); // Adjust the path to your background image
        Image backgroundImage = new Image(backgroundPath);
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(700); // Adjust to match your scene size
        backgroundImageView.setFitHeight(600); // Adjust to match your scene size
        backgroundImageView.setPreserveRatio(false); // Ensure it stretches to cover the scene
        backgroundImageView.setOpacity(0.5); // Optional: Set opacity if you want a lighter background

        Text title = new Text("CUI LOST AND FOUND");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        Button adminButton = new Button("Admin");
        Button studentButton = new Button("Student");
        Button hackerButton = new Button("Hacker");

        styleButton(adminButton);
        styleButton(studentButton);
        styleButton(hackerButton);

        adminButton.setOnAction(e -> showAdminMenu());
        studentButton.setOnAction(e -> showStudentMenu());
        hackerButton.setOnAction(e -> showHackerMenu());

        VBox vbox = new VBox(20, logoImageView, title, adminButton, studentButton, hackerButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));

        VBox whiteBox = new VBox(20, vbox);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        StackPane root = new StackPane();
        root.getChildren().addAll(backgroundImageView, whiteBox); // Add background first, then content
        root.setStyle("-fx-padding: 50;");

        Scene scene = new Scene(root, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("CUI LOST AND FOUND");
        primaryStage.show();
    }


    private void showAdminMenu() {
        Text title = new Text("Admin Menu");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        // Load the background image
        String backgroundPath = Paths.get("images/comsats.jpg").toUri().toString(); // Adjust the path to your background image
        Image backgroundImage = new Image(backgroundPath);
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(700); // Adjust to match your scene size
        backgroundImageView.setFitHeight(600); // Adjust to match your scene size
        backgroundImageView.setPreserveRatio(false); // Ensure it stretches to cover the scene
        backgroundImageView.setOpacity(0.5); // Optional: Set opacity if you want a lighter background

        Button loginButton = new Button("Login");
        Button registerButton = new Button("Register");
        Button backButton = new Button("Back");

        styleButton(loginButton);
        styleButton(registerButton);
        styleButton(backButton);

        loginButton.setOnAction(e -> showAdminLogin());
        registerButton.setOnAction(e -> showAdminRegistration());
        backButton.setOnAction(e -> showMainMenu());

        VBox vbox = new VBox(20, title, loginButton, registerButton, backButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));
        primaryStage.setTitle("Admin Menu");


        displayModuleMenu(vbox);
    }

    private void showStudentMenu() {
        Text title = new Text("Student Menu");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        Button loginButton = new Button("Login");
        Button registerButton = new Button("Register");
        Button backButton = new Button("Back");

        styleButton(loginButton);
        styleButton(registerButton);
        styleButton(backButton);

        loginButton.setOnAction(e -> showStudentLogin());
        registerButton.setOnAction(e -> showStudentRegistration());
        backButton.setOnAction(e -> showMainMenu());

        VBox vbox = new VBox(20, title, loginButton, registerButton, backButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));
        primaryStage.setTitle("Student Menu");

        displayModuleMenu(vbox);
    }

    private void showLoggedInStudentMenu() {
        Text title = new Text("Student Menu");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        Button foundItemButton = new Button("Found Item");
        Button lostItemButton = new Button("Lost Item");
        Button changePasswordButton = new Button("Change Password");
        Button logOutButton = new Button("Logout");

        styleButton(foundItemButton);
        styleButton(lostItemButton);
        styleButton(changePasswordButton);
        styleButton(logOutButton);

        foundItemButton.setOnAction(e -> foundItem());
        lostItemButton.setOnAction(e -> lostItem());
        changePasswordButton.setOnAction(e -> showStudentChangePassword());
        logOutButton.setOnAction(e -> showStudentMenu());

        VBox vbox = new VBox(20, title, foundItemButton, lostItemButton, changePasswordButton, logOutButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));

        primaryStage.setTitle("Student DashBoard");

        displayModuleMenu(vbox);
    }

    private void showLoggedInAdminMenu() {
        Text title = new Text("Admin Menu");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        Button foundItemsButton = new Button("Found Items Box");
        Button historyAndLogButton = new Button("History and Log");
        Button changeAccountStatusButton = new Button("Deactivate Student Account");
        Button logOutButton = new Button("Logout");
        Button backButton = new Button("Back");

        styleButton(foundItemsButton);
        styleButton(historyAndLogButton);
        styleButton(changeAccountStatusButton);
        styleButton(logOutButton);
        styleButton(backButton);

        backButton.setOnAction(e -> {

            showLoggedInAdminMenu();
        });

        foundItemsButton.setOnAction(e -> {
            primaryStage.setTitle("Found Items Box");
            service.displayFoundItems(primaryStage, backButton);

        });
        historyAndLogButton.setOnAction(e -> {
            primaryStage.setTitle("History and Log");
            service.displayHistoryAndLog(primaryStage, backButton);
        });

        changeAccountStatusButton.setOnAction(e -> {


            Text title2 = new Text("Deactivate Student Account");
            title2.setFont(Font.font("Arial", FontWeight.BOLD, 26));
            title2.setFill(Color.web("black"));

            Label student_id_lbl = new Label("Enter Student Id: ");

            student_id_lbl.setFont(Font.font("Arial", FontWeight.BOLD, 16));

            TextField student_id2 = new TextField();
            student_id2.setPromptText("Enter Student Id");


            Button confirmButton = new Button("Confirm");
            Button backButton2 = new Button("Back");


            styleButton(confirmButton);
            styleButton(backButton2);

            confirmButton.setOnAction(e2 -> {

                student_id = student_id2.getText();
                service.deactivateStudentAccount(Encryption.encrypt(student_id));

            });

            backButton2.setOnAction(e3 -> showLoggedInAdminMenu());

            HBox btns = new HBox(backButton2, confirmButton);
            btns.setSpacing(5);
            btns.setAlignment(Pos.CENTER);

            VBox vbox = new VBox(20, title2, student_id_lbl, student_id2, btns);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPadding(new Insets(20));

            VBox whiteBox = new VBox(20, vbox);
            whiteBox.setAlignment(Pos.CENTER);
            whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

            StackPane root = new StackPane(whiteBox);
            root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

            Scene scene = new Scene(root, 600, 600);
            primaryStage.setTitle("Deactivate Student Account");
            primaryStage.setScene(scene);


        });
        logOutButton.setOnAction(e -> showAdminMenu());

        VBox vbox = new VBox(20, title, foundItemsButton, historyAndLogButton, changeAccountStatusButton, logOutButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));
        primaryStage.setTitle("Admin DashBoard");

        displayModuleMenu(vbox);
    }

    private void showHackerMenu() {
        Text title = new Text("Hacker Menu");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        Button dataTheftButton = new Button("Data Theft");
        Button bruteForceButton = new Button("Brute Force");
        Button dosAttackButton = new Button("DoS Attack");
        Button programGoesByeByeButton = new Button("Surprise!!!");
        Button backButton = new Button("Back");
        Button backButton3 = new Button("Back");

        styleButton(dataTheftButton);
        styleButton(bruteForceButton);
        styleButton(dosAttackButton);
        styleButton(programGoesByeByeButton);
        styleButton(backButton);
        styleButton(backButton3);

        dataTheftButton.setOnAction(e -> {
            primaryStage.setTitle("Data Theft");
            hacker.DataTheft(service, primaryStage, backButton3);

        });
        bruteForceButton.setOnAction(e -> {
            primaryStage.setTitle("Brute Force");
            hacker.bruteForce(service, primaryStage, backButton3);

        });
        dosAttackButton.setOnAction(e -> {

            Text title2 = new Text("DoS Attack");
            title2.setFont(Font.font("Arial", FontWeight.BOLD, 36));
            title2.setFill(Color.web("red"));

            Label lbl_number = new Label("Enter No. of Attacks: ");
            TextField tf_number = new TextField();
            lbl_number.setFont(Font.font("Arial", FontWeight.BOLD, 16));


            Button confirmButton = new Button("Confirm");
            Button backButton2 = new Button("Back");


            styleButton(confirmButton);
            styleButton(backButton2);

            confirmButton.setOnAction(e2 -> {
                int numberOfAttacks = Integer.parseInt(tf_number.getText());
                hacker.DoS(service, numberOfAttacks);
                showHackerMenu();

            });

            backButton2.setOnAction(e3 -> showHackerMenu());

            HBox btns = new HBox(backButton2, confirmButton);
            btns.setSpacing(5);
            btns.setAlignment(Pos.CENTER);

            VBox vbox = new VBox(20, title2, lbl_number, tf_number, btns);
            vbox.setAlignment(Pos.CENTER);
            vbox.setPadding(new Insets(20));

            VBox whiteBox = new VBox(20, vbox);
            whiteBox.setAlignment(Pos.CENTER);
            whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

            StackPane root = new StackPane(whiteBox);
            root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

            Scene scene = new Scene(root, 600, 600);
            primaryStage.setTitle("DoS Attack");
            primaryStage.setScene(scene);


        });
        programGoesByeByeButton.setOnAction(e -> {


            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning!!!");
            alert.setHeaderText("Are you sure you want to initiate Self Destruct?");

            ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
            ButtonType yesButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);


            alert.getButtonTypes().setAll(noButton,yesButton );

            alert.showAndWait().ifPresent(response -> {
                if (response == yesButton) {
                    System.out.println("You chose yes");
                    primaryStage.setTitle("Self-Destruct");
                    hacker.selfDistruct(primaryStage);
                } else if (response == noButton) {
                    System.out.println("You chose no");
                    showHackerMenu();
                }
            });

        });

        backButton.setOnAction(e -> showMainMenu());
        backButton3.setOnAction(e -> showHackerMenu());

        VBox vbox = new VBox(20, title, dataTheftButton, bruteForceButton, dosAttackButton, programGoesByeByeButton, backButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));

        primaryStage.setTitle("Hacker DashBoard");

        displayModuleMenu(vbox);
    }

    private void styleButton(Button button) {
        button.setStyle("-fx-background-color: #2980b9; " + "-fx-text-fill: white; " + "-fx-font-size: 18px; " + "-fx-font-weight: bold; " + "-fx-padding: 10 20 10 20; " + "-fx-background-radius: 5; " + "-fx-cursor: hand; " + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);");

        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #3498db; " + "-fx-text-fill: white; " + "-fx-font-size: 18px; " + "-fx-font-weight: bold; " + "-fx-padding: 10 20 10 20; " + "-fx-background-radius: 5; " + "-fx-cursor: hand; " + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);"));

        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: #2980b9; " + "-fx-text-fill: white; " + "-fx-font-size: 18px; " + "-fx-font-weight: bold; " + "-fx-padding: 10 20 10 20; " + "-fx-background-radius: 5; " + "-fx-cursor: hand; " + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);"));
    }

    private void displayModuleMenu(VBox vbox) {
        // Load the logo image
        String logoPath = Paths.get("images/Comsats_logo.png").toUri().toString();
        Image logoImage = new Image(logoPath);
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitWidth(300); // Adjust the width to fit your layout
        logoImageView.setFitHeight(90); // Adjust the height to fit your layout

        // Load the background image
        String backgroundPath = Paths.get("images/comsats.jpg").toUri().toString(); // Adjust the path to your background image
        Image backgroundImage = new Image(backgroundPath);
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(700); // Adjust to match your scene size
        backgroundImageView.setFitHeight(600); // Adjust to match your scene size
        backgroundImageView.setPreserveRatio(false); // Ensure it stretches to cover the scene
        backgroundImageView.setOpacity(0.5); // Optional: Set opacity if you want a lighter background

        VBox whiteBox = new VBox(20, vbox);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        StackPane root = new StackPane(backgroundImageView, whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        Scene scene = new Scene(root, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showStudentRegistration() {
        // Create UI elements
        Label titleLabel = new Label("Student Registration");
        titleLabel.setFont(new Font("Arial", 30));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label idLabel = new Label("Id:");
        idLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField idField = new TextField();

        Label nameLabel = new Label("Name:");
        nameLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField nameField = new TextField();

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField passwordField = new PasswordField();
        TextField passwordFieldShown = new TextField();
        passwordFieldShown.setManaged(false);
        passwordFieldShown.setVisible(false);

        Button showPasswordButton = new Button("Show");
        showPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        showPasswordButton.setOnAction(e -> {
            if (showPasswordButton.getText().equals("Show")) {
                passwordFieldShown.setText(passwordField.getText());
                passwordFieldShown.setManaged(true);
                passwordFieldShown.setVisible(true);
                passwordField.setManaged(false);
                passwordField.setVisible(false);
                showPasswordButton.setText("Hide");
            } else {
                passwordField.setText(passwordFieldShown.getText());
                passwordField.setManaged(true);
                passwordField.setVisible(true);
                passwordFieldShown.setManaged(false);
                passwordFieldShown.setVisible(false);
                showPasswordButton.setText("Show");
            }
        });

        HBox passwordBox = new HBox(10, passwordField, passwordFieldShown, showPasswordButton);
        passwordBox.setAlignment(Pos.CENTER_LEFT);

        Label confirmPasswordLabel = new Label("Confirm Password:");
        confirmPasswordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField confirmPasswordField = new PasswordField();
        TextField confirmPasswordFieldShown = new TextField();
        confirmPasswordFieldShown.setManaged(false);
        confirmPasswordFieldShown.setVisible(false);

        Button showConfirmPasswordButton = new Button("Show");
        showConfirmPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        showConfirmPasswordButton.setOnAction(e -> {
            if (showConfirmPasswordButton.getText().equals("Show")) {
                confirmPasswordFieldShown.setText(confirmPasswordField.getText());
                confirmPasswordFieldShown.setManaged(true);
                confirmPasswordFieldShown.setVisible(true);
                confirmPasswordField.setManaged(false);
                confirmPasswordField.setVisible(false);
                showConfirmPasswordButton.setText("Hide");
            } else {
                confirmPasswordField.setText(confirmPasswordFieldShown.getText());
                confirmPasswordField.setManaged(true);
                confirmPasswordField.setVisible(true);
                confirmPasswordFieldShown.setManaged(false);
                confirmPasswordFieldShown.setVisible(false);
                showConfirmPasswordButton.setText("Show");
            }
        });

        HBox confirmPasswordBox = new HBox(10, confirmPasswordField, confirmPasswordFieldShown, showConfirmPasswordButton);
        confirmPasswordBox.setAlignment(Pos.CENTER_LEFT);

        Label genderLabel = new Label("Gender:");
        genderLabel.setStyle("-fx-text-fill: #2c3e50;");
        RadioButton maleRadioButton = new RadioButton("Male");
        RadioButton femaleRadioButton = new RadioButton("Female");
        ToggleGroup genderGroup = new ToggleGroup();
        maleRadioButton.setToggleGroup(genderGroup);
        femaleRadioButton.setToggleGroup(genderGroup);

        HBox genderBox = new HBox(10, maleRadioButton, femaleRadioButton);
        genderBox.setAlignment(Pos.CENTER_LEFT);

        Label ageLabel = new Label("Age:");
        ageLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField ageField = new TextField();

        Label semesterLabel = new Label("Semester:");
        semesterLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> semesterComboBox = new ComboBox<>();
        semesterComboBox.setPromptText("Select Semester");
        for (int i = 1; i <= 8; i++) {
            semesterComboBox.getItems().add(Integer.toString(i));
        }

        Button registerButton = new Button("Register");
        registerButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red;");

        registerButton.setOnAction(e -> {
            if (!passwordField.getText().equals(confirmPasswordField.getText())) {
                messageLabel.setText("Passwords do not match!");
            } else {
                messageLabel.setText("Registration successful!");
                messageLabel.setStyle("-fx-text-fill: green;");
                // Add code to handle registration logic here


                student_id = idField.getText();


                student_password = passwordField.getText();

                student_name = nameField.getText();

                student_age = ageField.getText();


                RadioButton selectedOption = (RadioButton) genderGroup.getSelectedToggle();
                String student_gender = selectedOption.getText();


                student_semester = semesterComboBox.getValue();

                System.out.println(student_id);
                System.out.println(student_name);
                System.out.println(student_password);
                System.out.println(student_age);
                System.out.println(student_gender);
                System.out.println(student_semester);

                service.registerStudent(Encryption.encrypt(student_id), Encryption.encrypt(student_password), Encryption.encrypt(student_name), Encryption.encrypt(student_age), Encryption.encrypt(student_gender), Encryption.encrypt(student_semester));


            }
        });

        // Arrange elements in a GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(idLabel, 0, 0);
        gridPane.add(idField, 1, 0, 2, 1);

        gridPane.add(nameLabel, 0, 1);
        gridPane.add(nameField, 1, 1, 2, 1);

        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordBox, 1, 2, 2, 1);

        gridPane.add(confirmPasswordLabel, 0, 3);
        gridPane.add(confirmPasswordBox, 1, 3, 2, 1);

        gridPane.add(genderLabel, 0, 4);
        gridPane.add(genderBox, 1, 4, 2, 1);

        gridPane.add(ageLabel, 0, 5);
        gridPane.add(ageField, 1, 5, 2, 1);

        gridPane.add(semesterLabel, 0, 6);
        gridPane.add(semesterComboBox, 1, 6, 2, 1);

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {
            showStudentMenu();
        });
        // gridPane.add(backButton, 0, 7, 2, 1);
        //  GridPane.setHalignment(backButton, javafx.geometry.HPos.CENTER);
        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, registerButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 7, 2, 1);

        gridPane.add(messageLabel, 1, 8, 2, 1);

        // Create a white box with border shadow
        VBox whiteBox = new VBox(20, titleLabel, gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Student Registration");
        primaryStage.setScene(scene);

    }

    public void showStudentLogin() {


        // Create UI elements
        Label loginTitle = new Label("Student Login");
        loginTitle.setFont(new Font("Arial", 30)); // Larger font for the title
        loginTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label IdLabel = new Label("ID:");
        IdLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField IdField = new TextField();
        IdField.setPromptText("Enter ID");

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        TextField showPasswordField = new TextField();
        showPasswordField.setManaged(false);
        showPasswordField.setVisible(false);
        showPasswordField.setPromptText("Password");

        Button showPasswordButton = new Button("Show");
        showPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 12px;");
        showPasswordButton.setOnAction(e -> {
            if (showPasswordButton.getText().equals("Show")) {
                showPasswordField.setText(passwordField.getText());
                showPasswordField.setManaged(true);
                showPasswordField.setVisible(true);
                passwordField.setManaged(false);
                passwordField.setVisible(false);
                showPasswordButton.setText("Hide");
            } else {
                passwordField.setText(showPasswordField.getText());
                showPasswordField.setManaged(false);
                showPasswordField.setVisible(false);
                passwordField.setManaged(true);
                passwordField.setVisible(true);
                showPasswordButton.setText("Show");
            }
        });

        Button loginButton = new Button("Log in");
        loginButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");

        loginButton.setOnAction(e -> {

            student_id = IdField.getText();
            student_password = passwordField.getText();

            boolean student_login_status = service.loginStudent(Encryption.encrypt(student_id), Encryption.encrypt(student_password));

            if (student_login_status) showLoggedInStudentMenu();


        });


        // Use GridPane for better alignment
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(20));
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(loginTitle, 0, 0, 3, 1); // Span across three columns to center
        GridPane.setHalignment(loginTitle, javafx.geometry.HPos.CENTER);
        GridPane.setMargin(loginTitle, new Insets(0, 0, 20, 0));

        gridPane.add(IdLabel, 0, 1);
        gridPane.add(IdField, 1, 1, 2, 1); // Span across two columns for better alignment

        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(showPasswordField, 1, 2);
        gridPane.add(showPasswordButton, 2, 2);

        GridPane.setMargin(showPasswordButton, new Insets(0, 0, 0, 10));

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {
            showStudentMenu();
        });
        gridPane.add(backButton, 0, 7, 2, 1);
        GridPane.setHalignment(backButton, javafx.geometry.HPos.CENTER);
        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, loginButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 3, 3, 1); // Span across three columns to center

        // Create a white box with border shadow
        VBox whiteBox = new VBox(gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Student Login");
        primaryStage.setScene(scene);

    }

    public void showStudentChangePassword() {


        // Create UI elements
        Label loginTitle = new Label("Change Password");
        loginTitle.setFont(new Font("Arial", 30)); // Larger font for the title
        loginTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label IdLabel = new Label("ID:");
        IdLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField IdField = new TextField();
        IdField.setPromptText("Enter ID");

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        TextField showPasswordField = new TextField();
        showPasswordField.setManaged(false);
        showPasswordField.setVisible(false);
        showPasswordField.setPromptText("Password");

        Label newPasswordLabel = new Label("New Password:");
        newPasswordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New Password");
        TextField showNewPasswordField = new TextField();
        showNewPasswordField.setManaged(false);
        showNewPasswordField.setVisible(false);
        showNewPasswordField.setPromptText("New Password");

        Button showPasswordButton = new Button("Show");
        showPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 12px;");
        showPasswordButton.setOnAction(e -> {
            if (showPasswordButton.getText().equals("Show")) {
                showPasswordField.setText(passwordField.getText());
                showPasswordField.setManaged(true);
                showPasswordField.setVisible(true);
                passwordField.setManaged(false);
                passwordField.setVisible(false);
                showPasswordButton.setText("Hide");
            } else {
                passwordField.setText(showPasswordField.getText());
                showPasswordField.setManaged(false);
                showPasswordField.setVisible(false);
                passwordField.setManaged(true);
                passwordField.setVisible(true);
                showPasswordButton.setText("Show");
            }
        });

        Button showNewPasswordButton = new Button("Show");
        showNewPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 12px;");
        showNewPasswordButton.setOnAction(e -> {
            if (showNewPasswordButton.getText().equals("Show")) {
                showNewPasswordField.setText(newPasswordField.getText());
                showNewPasswordField.setManaged(true);
                showNewPasswordField.setVisible(true);
                newPasswordField.setManaged(false);
                newPasswordField.setVisible(false);
                showNewPasswordButton.setText("Hide");
            } else {
                newPasswordField.setText(showNewPasswordField.getText());
                showNewPasswordField.setManaged(false);
                showNewPasswordField.setVisible(false);
                newPasswordField.setManaged(true);
                newPasswordField.setVisible(true);
                showNewPasswordButton.setText("Show");
            }
        });

        Button confirmButton = new Button("Confirm");
        confirmButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");

        confirmButton.setOnAction(e -> {

            student_id = IdField.getText();
            student_password = passwordField.getText();
            student_new_password = newPasswordField.getText();

            boolean student_login_status = service.loginStudent(Encryption.encrypt(student_id), Encryption.encrypt(student_password));

            if (student_login_status)
                service.changePassword(Encryption.encrypt(student_id), Encryption.encrypt(student_password), Encryption.encrypt(student_new_password));

            showLoggedInStudentMenu();

        });


        // Use GridPane for better alignment
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(20));
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(loginTitle, 0, 0, 3, 1); // Span across three columns to center
        GridPane.setHalignment(loginTitle, javafx.geometry.HPos.CENTER);
        GridPane.setMargin(loginTitle, new Insets(0, 0, 20, 0));

        gridPane.add(IdLabel, 0, 1);
        gridPane.add(IdField, 1, 1, 2, 1); // Span across two columns for better alignment

        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(showPasswordField, 1, 2);
        gridPane.add(showPasswordButton, 2, 2);

        gridPane.add(newPasswordLabel, 0, 3);
        gridPane.add(newPasswordField, 1, 3);
        gridPane.add(showNewPasswordField, 1, 3);
        gridPane.add(showNewPasswordButton, 2, 3);

        GridPane.setMargin(showPasswordButton, new Insets(0, 0, 0, 10));
        GridPane.setMargin(showNewPasswordButton, new Insets(0, 0, 0, 10));

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {
            showLoggedInStudentMenu();
        });
        gridPane.add(backButton, 0, 7, 2, 1);
        GridPane.setHalignment(backButton, javafx.geometry.HPos.CENTER);
        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, confirmButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 4, 3, 1); // Span across three columns to center

        // Create a white box with border shadow
        VBox whiteBox = new VBox(gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Change Password");
        primaryStage.setScene(scene);

    }

    private void showAdminRegistration() {
        // Create UI elements
        Label titleLabel = new Label("Admin Registration");
        titleLabel.setFont(new Font("Arial", 30));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label idLabel = new Label("Id:");
        idLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField idField = new TextField();


        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField passwordField = new PasswordField();
        TextField passwordFieldShown = new TextField();
        passwordFieldShown.setManaged(false);
        passwordFieldShown.setVisible(false);

        Button showPasswordButton = new Button("Show");
        showPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        showPasswordButton.setOnAction(e -> {
            if (showPasswordButton.getText().equals("Show")) {
                passwordFieldShown.setText(passwordField.getText());
                passwordFieldShown.setManaged(true);
                passwordFieldShown.setVisible(true);
                passwordField.setManaged(false);
                passwordField.setVisible(false);
                showPasswordButton.setText("Hide");
            } else {
                passwordField.setText(passwordFieldShown.getText());
                passwordField.setManaged(true);
                passwordField.setVisible(true);
                passwordFieldShown.setManaged(false);
                passwordFieldShown.setVisible(false);
                showPasswordButton.setText("Show");
            }
        });

        HBox passwordBox = new HBox(10, passwordField, passwordFieldShown, showPasswordButton);
        passwordBox.setAlignment(Pos.CENTER_LEFT);

        Label confirmPasswordLabel = new Label("Confirm Password:");
        confirmPasswordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField confirmPasswordField = new PasswordField();
        TextField confirmPasswordFieldShown = new TextField();
        confirmPasswordFieldShown.setManaged(false);
        confirmPasswordFieldShown.setVisible(false);

        Button showConfirmPasswordButton = new Button("Show");
        showConfirmPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        showConfirmPasswordButton.setOnAction(e -> {
            if (showConfirmPasswordButton.getText().equals("Show")) {
                confirmPasswordFieldShown.setText(confirmPasswordField.getText());
                confirmPasswordFieldShown.setManaged(true);
                confirmPasswordFieldShown.setVisible(true);
                confirmPasswordField.setManaged(false);
                confirmPasswordField.setVisible(false);
                showConfirmPasswordButton.setText("Hide");
            } else {
                confirmPasswordField.setText(confirmPasswordFieldShown.getText());
                confirmPasswordField.setManaged(true);
                confirmPasswordField.setVisible(true);
                confirmPasswordFieldShown.setManaged(false);
                confirmPasswordFieldShown.setVisible(false);
                showConfirmPasswordButton.setText("Show");
            }
        });

        HBox confirmPasswordBox = new HBox(10, confirmPasswordField, confirmPasswordFieldShown, showConfirmPasswordButton);
        confirmPasswordBox.setAlignment(Pos.CENTER_LEFT);


        Button registerButton = new Button("Register");
        registerButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");


        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red;");

        registerButton.setOnAction(e -> {
            if (!passwordField.getText().equals(confirmPasswordField.getText())) {
                messageLabel.setText("Passwords do not match!");
            } else {
                messageLabel.setText("Registration successful!");
                messageLabel.setStyle("-fx-text-fill: green;");
                // Add code to handle registration logic here


                admin_id = idField.getText();

                admin_password = passwordField.getText();

                System.out.println(admin_id);
                System.out.println(admin_password);
                service.registerAdmin(Encryption.encrypt(admin_id), Encryption.encrypt(admin_password));
            }
        });


        // Arrange elements in a GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(idLabel, 0, 0);
        gridPane.add(idField, 1, 0, 2, 1);


        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordBox, 1, 2, 2, 1);

        gridPane.add(confirmPasswordLabel, 0, 3);
        gridPane.add(confirmPasswordBox, 1, 3, 2, 1);


        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {
            showAdminMenu();
        });

        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, registerButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 4, 2, 1);


        gridPane.add(messageLabel, 1, 5, 2, 1);

        // Create a white box with border shadow
        VBox whiteBox = new VBox(20, titleLabel, gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Admin Registration");
        primaryStage.setScene(scene);

    }

    public void showAdminLogin() {


        // Create UI elements
        Label loginTitle = new Label("Admin Login");
        loginTitle.setFont(new Font("Arial", 30)); // Larger font for the title
        loginTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label emailLabel = new Label("ID:");
        emailLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField idField = new TextField();
        idField.setPromptText("Enter ID");

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-text-fill: #2c3e50;");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        TextField showPasswordField = new TextField();
        showPasswordField.setManaged(false);
        showPasswordField.setVisible(false);
        showPasswordField.setPromptText("Password");

        Button showPasswordButton = new Button("Show");
        showPasswordButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 12px;");
        showPasswordButton.setOnAction(e -> {
            if (showPasswordButton.getText().equals("Show")) {
                showPasswordField.setText(passwordField.getText());
                showPasswordField.setManaged(true);
                showPasswordField.setVisible(true);
                passwordField.setManaged(false);
                passwordField.setVisible(false);
                showPasswordButton.setText("Hide");
            } else {
                passwordField.setText(showPasswordField.getText());
                showPasswordField.setManaged(false);
                showPasswordField.setVisible(false);
                passwordField.setManaged(true);
                passwordField.setVisible(true);
                showPasswordButton.setText("Show");
            }
        });

        Button loginButton = new Button("Log in");
        loginButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");

        loginButton.setOnAction(e -> {


            admin_id = idField.getText();

            admin_password = passwordField.getText();

            System.out.println(admin_id);
            System.out.println(admin_password);

            boolean admin_login_status = service.loginAdmin(Encryption.encrypt(admin_id), Encryption.encrypt(admin_password));

            if (admin_login_status) showLoggedInAdminMenu();


        });

        // Use GridPane for better alignment
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(20));
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(loginTitle, 0, 0, 3, 1); // Span across three columns to center
        GridPane.setHalignment(loginTitle, javafx.geometry.HPos.CENTER);
        GridPane.setMargin(loginTitle, new Insets(0, 0, 20, 0));

        gridPane.add(emailLabel, 0, 1);
        gridPane.add(idField, 1, 1, 2, 1); // Span across two columns for better alignment

        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(showPasswordField, 1, 2);
        gridPane.add(showPasswordButton, 2, 2);

        GridPane.setMargin(showPasswordButton, new Insets(0, 0, 0, 10));


        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {
            showAdminMenu();
        });
        gridPane.add(backButton, 0, 7, 2, 1);
        GridPane.setHalignment(backButton, javafx.geometry.HPos.CENTER);
        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, loginButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 3, 3, 1); // Span across three columns to center

        // Create a white box with border shadow
        VBox whiteBox = new VBox(gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Admin Login");
        primaryStage.setScene(scene);

    }

    public void foundItem() {
        // Create UI elements
        Label titleLabel = new Label("Item Details");
        titleLabel.setFont(new Font("Arial", 30));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label itemImageLabel = new Label("Item Image:");
        itemImageLabel.setStyle("-fx-text-fill: #2c3e50;");
        ImageView itemImageView = new ImageView();
        itemImageView.setFitWidth(100);
        itemImageView.setFitHeight(100);
        itemImageView.setStyle("-fx-border-color: #2c3e50; -fx-border-width: 1px;");
        Button chooseImageButton = new Button("Choose Image");
        chooseImageButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");

        // FileChooser to select an image
        FileChooser fileChooser = new FileChooser();
        chooseImageButton.setOnAction(e -> {
            File file = fileChooser.showOpenDialog(primaryStage);
            if (file != null) {
                item_image = file.getName();
                System.out.println("Selected image: " + item_image);

                Image image = new Image(file.toURI().toString());

                itemImageView.setImage(image);
            }
        });

        Label itemNameLabel = new Label("Item Name:");
        itemNameLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField itemNameField = new TextField();

        Label itemCategoryLabel = new Label("Item Category:");
        itemCategoryLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> itemCategoryComboBox = new ComboBox<>();
        itemCategoryComboBox.getItems().addAll("Personal Item", "Electronics", "Clothing", "Furniture", "Accessories", "Cosmetics", "Home Appliances", "Sports", "Books", "Food", "Vehicle", "Other");

        Label itemColorLabel = new Label("Item Color:");
        itemColorLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> itemColorComboBox = new ComboBox<>();
        itemColorComboBox.getItems().addAll("Red", "Green", "Blue", "Grey", "White", "Brown", "Yellow", "Orange", "Black", "Purple", "Pink", "Other");

        Label itemLocationLabel = new Label("Item Location:");
        itemLocationLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> itemLocationComboBox = new ComboBox<>();
        itemLocationComboBox.getItems().addAll("N-Block", "C-Block", "D-Block", "H-Block", "Cafeteria", "Parking", "Gym", "Gate-1", "Gate-2", "Gate-3", "Admission Office");

        Label itemDescriptionLabel = new Label("Item Description:");
        itemDescriptionLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextArea itemDescriptionArea = new TextArea();
        itemDescriptionArea.setPrefRowCount(4);

        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");

        submitButton.setOnAction(e -> {


            item_name = itemNameField.getText();

            item_category = itemCategoryComboBox.getValue();
            item_color = itemColorComboBox.getValue();
            item_location = itemLocationComboBox.getValue();
            item_description = itemDescriptionArea.getText();

            System.out.println(item_image);
            System.out.println(item_name);
            System.out.println(item_category);
            System.out.println(item_color);
            System.out.println(item_location);
            System.out.println(item_description);


            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success!");
            alert.setHeaderText(null);
            alert.setHeaderText("Request Submitted!");
            alert.showAndWait();


            service.addFoundItem(Encryption.encrypt(student_id), Encryption.encrypt(student_name), Encryption.encrypt(item_image), Encryption.encrypt(item_name), Encryption.encrypt(item_category), Encryption.encrypt(item_color), Encryption.encrypt(item_location), Encryption.encrypt(item_description));

            showLoggedInStudentMenu();

        });

        // Arrange elements in a GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(itemImageLabel, 0, 0);
        gridPane.add(chooseImageButton, 1, 0);
        gridPane.add(itemImageView, 2, 0);


        gridPane.add(itemNameLabel, 0, 1);
        gridPane.add(itemNameField, 1, 1, 2, 1);

        gridPane.add(itemCategoryLabel, 0, 2);
        gridPane.add(itemCategoryComboBox, 1, 2, 2, 1);

        gridPane.add(itemColorLabel, 0, 3);
        gridPane.add(itemColorComboBox, 1, 3, 2, 1);

        gridPane.add(itemLocationLabel, 0, 4);
        gridPane.add(itemLocationComboBox, 1, 4, 2, 1);

        gridPane.add(itemDescriptionLabel, 0, 5);
        gridPane.add(itemDescriptionArea, 1, 5, 2, 1);

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {
            showLoggedInStudentMenu();
        });

        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, submitButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 6, 3, 1);


        // Create a white box with border shadow
        VBox whiteBox = new VBox(20, titleLabel, gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Found Item Form");
        primaryStage.setScene(scene);
    }

    public void lostItem() {
        // Create UI elements
        Label titleLabel = new Label("Item Details");
        titleLabel.setFont(new Font("Arial", 30));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label itemImageLabel = new Label("Item Image:");
        itemImageLabel.setStyle("-fx-text-fill: #2c3e50;");
        ImageView itemImageView = new ImageView();
        itemImageView.setFitWidth(100);
        itemImageView.setFitHeight(100);
        itemImageView.setStyle("-fx-border-color: #2c3e50; -fx-border-width: 1px;");
        Button chooseImageButton = new Button("Choose Image");
        chooseImageButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");

        // FileChooser to select an image
        FileChooser fileChooser = new FileChooser();
        chooseImageButton.setOnAction(e -> {
            File file = fileChooser.showOpenDialog(primaryStage);
            if (file != null) {
                item_image = file.getName();
                System.out.println("Selected image: " + item_image);

                Image image = new Image(file.toURI().toString());
                itemImageView.setImage(image);
            }
        });

        Label itemNameLabel = new Label("Item Name:");
        itemNameLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextField itemNameField = new TextField();

        Label itemCategoryLabel = new Label("Item Category:");
        itemCategoryLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> itemCategoryComboBox = new ComboBox<>();
        itemCategoryComboBox.getItems().addAll("Personal Item", "Electronics", "Clothing", "Furniture", "Accessories", "Cosmetics", "Home Appliances", "Sports", "Books", "Food", "Vehicle", "Other");

        Label itemColorLabel = new Label("Item Color:");
        itemColorLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> itemColorComboBox = new ComboBox<>();
        itemColorComboBox.getItems().addAll("Red", "Green", "Blue", "Grey", "White", "Brown", "Yellow", "Orange", "Black", "Purple", "Pink", "Other");

        Label itemLocationLabel = new Label("Item Location:");
        itemLocationLabel.setStyle("-fx-text-fill: #2c3e50;");
        ComboBox<String> itemLocationComboBox = new ComboBox<>();
        itemLocationComboBox.getItems().addAll("N-Block", "C-Block", "D-Block", "H-Block", "Cafeteria", "Parking", "Gym", "Gate-1", "Gate-2", "Gate-3", "Admission Office");


        Label itemDescriptionLabel = new Label("Item Description:");
        itemDescriptionLabel.setStyle("-fx-text-fill: #2c3e50;");
        TextArea itemDescriptionArea = new TextArea();
        itemDescriptionArea.setPrefRowCount(4);

        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");

        submitButton.setOnAction(e -> {


            item_name = itemNameField.getText();

            item_category = itemCategoryComboBox.getValue();
            item_color = itemColorComboBox.getValue();
            item_location = itemLocationComboBox.getValue();
            item_description = itemDescriptionArea.getText();

            System.out.println(item_image);
            System.out.println(item_name);
            System.out.println(item_category);
            System.out.println(item_color);
            System.out.println(item_location);
            System.out.println(item_description);


            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success!");
            alert.setHeaderText(null);
            alert.setHeaderText("Request Submitted!");
            alert.showAndWait();

            showLoggedInStudentMenu();
            service.findingOwner(Encryption.encrypt(student_id), Encryption.encrypt(student_name), Encryption.encrypt(item_image), Encryption.encrypt(item_name), Encryption.encrypt(item_category), Encryption.encrypt(item_color), Encryption.encrypt(item_location), Encryption.encrypt(item_description));


        });

        // Arrange elements in a GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(itemImageLabel, 0, 0);
        gridPane.add(chooseImageButton, 1, 0);
        gridPane.add(itemImageView, 2, 0);


        gridPane.add(itemNameLabel, 0, 1);
        gridPane.add(itemNameField, 1, 1, 2, 1);

        gridPane.add(itemCategoryLabel, 0, 2);
        gridPane.add(itemCategoryComboBox, 1, 2, 2, 1);

        gridPane.add(itemColorLabel, 0, 3);
        gridPane.add(itemColorComboBox, 1, 3, 2, 1);

        gridPane.add(itemLocationLabel, 0, 4);
        gridPane.add(itemLocationComboBox, 1, 4, 2, 1);

        gridPane.add(itemDescriptionLabel, 0, 5);
        gridPane.add(itemDescriptionArea, 1, 5, 2, 1);


        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20 10 20;");
        backButton.setOnAction(e -> {


            showLoggedInStudentMenu();
        });

        HBox backBox = new HBox();
        backBox.getChildren().addAll(backButton, submitButton);
        backBox.setSpacing(5);

        GridPane.setHalignment(backBox, javafx.geometry.HPos.CENTER);
        gridPane.add(backBox, 1, 6, 3, 1);


        // Create a white box with border shadow
        VBox whiteBox = new VBox(20, titleLabel, gridPane);
        whiteBox.setAlignment(Pos.CENTER);
        whiteBox.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0.5, 0, 0);");

        // Create a root pane with padding to center the white box
        StackPane root = new StackPane(whiteBox);
        root.setStyle("-fx-padding: 50; -fx-background-color: #ecf0f1;");

        // Create a scene and display it
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setTitle("Lost Item Form");
        primaryStage.setScene(scene);
    }

}