package org.example.cuilostandfound;

import java.io.Serializable;

public class Item implements Serializable {
    private String item_image;
    private String item_name;
    private String item_category;
    private String item_color;
    private String item_location;
    private String item_description; // optional

    public Item(String item_image, String item_name, String item_category, String item_color, String item_location, String item_description) {
        this.item_image = item_image;
        this.item_name = item_name;
        this.item_category = item_category;
        this.item_color = item_color;
        this.item_location = item_location;
        this.item_description = item_description;
    }

    public String getItem_name() {
        return item_name;
    }

    public String getItem_category() {
        return item_category;
    }

    public String getItem_color() {
        return item_color;
    }

    public String getItem_location() {
        return item_location;
    }

    public String getItem_description() {
        return item_description;
    }

    public String getItem_image() {
        return item_image;
    }
}
