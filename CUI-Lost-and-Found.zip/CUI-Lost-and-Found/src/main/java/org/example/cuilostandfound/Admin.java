// This class is created to show that admin class is different from service class
package org.example.cuilostandfound;

abstract class Admin {
}
