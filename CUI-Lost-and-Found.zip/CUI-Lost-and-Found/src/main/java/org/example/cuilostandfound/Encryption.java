package org.example.cuilostandfound;

public class Encryption {
    private static final int SHIFT = 3; // Shift value for the Caesar cipher

    // Method to encrypt a plaintext message
    public static String encrypt(String plaintext) {
        StringBuilder ciphertext = new StringBuilder();

        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);
            if (Character.isLetter(ch)) {
                char shifted = (char) (ch + SHIFT);
                if (Character.isUpperCase(ch)) {
                    if (shifted > 'Z') {
                        shifted -= 26;
                    }
                } else if (Character.isLowerCase(ch)) {
                    if (shifted > 'z') {
                        shifted -= 26;
                    }
                }
                ciphertext.append(shifted);
            } else {
                ciphertext.append(ch);
            }
        }

        return ciphertext.toString();
    }

    // Method to decrypt a ciphertext message
    public static String decrypt(String ciphertext) {
        StringBuilder plaintext = new StringBuilder();

        for (int i = 0; i < ciphertext.length(); i++) {
            char ch = ciphertext.charAt(i);
            if (Character.isLetter(ch)) {
                char shifted = (char) (ch - SHIFT);
                if (Character.isUpperCase(ch)) {
                    if (shifted < 'A') {
                        shifted += 26;
                    }
                } else if (Character.isLowerCase(ch)) {
                    if (shifted < 'a') {
                        shifted += 26;
                    }
                }
                plaintext.append(shifted);
            } else {
                plaintext.append(ch);
            }
        }

        return plaintext.toString();
    }
}