package org.example.cuilostandfound;

import java.io.Serializable;

public class Account implements Serializable {
    private String id;
    private String password;

    public Account (String id, String password){
        this.id = id;
        setPassword(password);
    }



    public void setPassword (String password){
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

}
