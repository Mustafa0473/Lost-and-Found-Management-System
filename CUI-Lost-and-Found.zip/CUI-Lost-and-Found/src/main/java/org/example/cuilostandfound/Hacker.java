package org.example.cuilostandfound;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Hacker {
    private String id = "207";


    public void DataTheft(Service service, Stage stage, Button backButton) {
        service.displayHistoryAndLogEncrypted(stage, backButton);
    }


    public void bruteForce(Service service, Stage stage, Button backButton) {
        BruteForce.bruteForce(service, stage, backButton);
    }

    public void DoS(Service service, int numberOfAttacks) {


        for (int i = 0; i < numberOfAttacks; i++) {
            String student_id = RandomGenerator.randomId();
            String student_name = RandomGenerator.randomStudentName();

            String item_image = RandomGenerator.randomImage();
            System.out.println(item_image);

            String item_name = RandomGenerator.randomName();

            String item_category = RandomGenerator.randomCategory();
            String item_color = RandomGenerator.randomColor();
            String item_location = RandomGenerator.randomLocation();
            String item_description = RandomGenerator.randomSentence();

            service.addFoundItem(Encryption.encrypt(student_id), Encryption.encrypt(student_name), Encryption.encrypt(item_image), Encryption.encrypt(item_name), Encryption.encrypt(item_category), Encryption.encrypt(item_color), Encryption.encrypt(item_location), Encryption.encrypt(item_description));

        }

    }

    public void selfDistruct(Stage stage) {
        SelfDestructCountdown.iniciateSelfDistruct(stage);
    }

}
