package org.example.cuilostandfound;

import java.io.Serializable;

public class Student implements Serializable {
    private String student_id;
    private String student_name;
    private Item item;

    public Student(String student_id, String student_name, Item item) {
        this.student_id = student_id;
        this.student_name = student_name;
        this.item = item;
    }

    public String getStudent_name() {
        return student_name;
    }

    public String getStudent_id(){
        return student_id;
    }
    public Item getItem (){
        return item;
    }
}
