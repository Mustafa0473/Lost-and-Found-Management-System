package org.example.cuilostandfound;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.concurrent.atomic.AtomicInteger;


public class SelfDestructCountdown {

    public static void iniciateSelfDistruct(Stage stage) {
        stage.setTitle("Self Destruct Countdown");

        Label label = new Label("Self Destruct in: 10");
        label.setFont(Font.font("Arial", FontWeight.BOLD, 40));
        label.setStyle("-fx-text-fill: red;");

        StackPane root = new StackPane();
        root.getChildren().add(label);

        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);
        stage.show();

        Timeline timeline = new Timeline();
        timeline.setCycleCount(10);

        AtomicInteger count = new AtomicInteger(10);
        timeline.getKeyFrames().add(
                new KeyFrame(
                        Duration.seconds(1),
                        event -> {
                            count.getAndDecrement();
                            label.setText("Self Destruct in: " + count);
                            if (count.get() == 0) {
                                stage.close();
                                SelfDistruct.selfdistruct();
                            }
                        }
                )
        );

        timeline.play();


    }
}

