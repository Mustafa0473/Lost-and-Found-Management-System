package org.example.cuilostandfound;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomGenerator {

    public static String randomId() {

        String student_id;

        Random rand = new Random();
        int number = rand.nextInt(900) + 100; // generates a number between 100 and 999
        student_id = "FA23-BSE-" + String.format("%03d", number);

        return student_id;
    }

    public static String randomWord() {
        List<String> words = new ArrayList<>();
        words.add("apple");
        words.add("banana");
        words.add("cherry");
        words.add("date");
        words.add("elderberry");

        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;
    }

    public static String randomSentence() {


        String chars = "abcdefghijklmnopqrstuvwxyz";
        Random rand = new Random();
        StringBuilder randomString = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            randomString.append(chars.charAt(rand.nextInt(chars.length())));
        }

        return randomString.toString();

    }

    public static String randomImage() {


        List<String> words = new ArrayList<>();
        words.add("bottle1.jpg");
        words.add("bottle2.jpg");
        words.add("bag1.jpg");
        words.add("bag2.jpg");
        words.add("headphones1.jpg");
        words.add("headphones2.jpg");
        words.add("glasses1.jpg");
        words.add("glasses2.jpg");
        words.add("wallet1.jpg");
        words.add("wallet2.jpg");
        words.add("pouch1.jpg");
        words.add("pouch2.jpg");
        words.add("sofa1.jpg");
        words.add("sofa2.jpg");


        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;

    }

    public static String randomName() {
        List<String> words = new ArrayList<>();
        words.add("Bottle");
        words.add("Sofa");
        words.add("Bag");
        words.add("Glasses");
        words.add("Wallet");


        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;
    }

    public static String randomColor() {
        List<String> words = new ArrayList<>();
        words.add("Red");
        words.add("Green");
        words.add("White");
        words.add("Grey");
        words.add("Brown");
        words.add("Black");
        words.add("Orange");
        words.add("Yellow");


        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;
    }

    public static String randomCategory() {
        List<String> words = new ArrayList<>();
        words.add("Electronics");
        words.add("Cosmetics");
        words.add("Sports");
        words.add("Accessories");
        words.add("Furniture");
        words.add("Clothing");
        words.add("Books");
        words.add("Personal Items");


        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;
    }

    public static String randomLocation() {
        List<String> words = new ArrayList<>();
        words.add("N-Block");
        words.add("C-Block");
        words.add("D-Block");
        words.add("H-Block");
        words.add("Cafeteria");
        words.add("Gym");
        words.add("Parking");
        words.add("Admission Office");
        words.add("Gate 1");
        words.add("Gate 2");
        words.add("Gate 3");

        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;
    }

    public static String randomStudentName() {
        List<String> words = new ArrayList<>();
        words.add("Ali");
        words.add("Ahmed");
        words.add("Talha");
        words.add("Akbar");
        words.add("Javed");
        words.add("Arshad");
        words.add("Zubair");
        words.add("Faraz");
        Random rand = new Random();
        String randomWord = words.get(rand.nextInt(words.size()));

        return randomWord;
    }
}
