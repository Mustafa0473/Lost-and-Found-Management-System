package org.example.cuilostandfound;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Service {

    // File paths for data storage
    private static final String STUDENT_REGISTERATION_FILE = "student_registeration.txt";
    private static final String ADMIN_REGISTERATION_FILE = "admin_registeration.txt";
    private static final String FOUND_ITEMS_FILE = "found_items.txt";
    private static final String HISTORY_AND_LOG_FILE = "history_and_log.txt";

    // Image Comparator object
    ImageComparator imageComparator = new ImageComparator();

    // Student Module related attributes
    private ArrayList<Student> found_items = new ArrayList<>();
    private ArrayList<Student> history_and_log = new ArrayList<>();
    private ArrayList<StudentAccount> student_registeration_log = new ArrayList<>();

    // Admin module related attributes
    private Account admin_registeration;

    // Constructor
    public Service() {
        initializeFileStreams();
        readAllData();  // Read data from files when Service is instantiated
    }

    private void initializeFileStreams() {
        try {
            // Ensure all files exist by creating them if necessary
            new FileOutputStream(ADMIN_REGISTERATION_FILE, true).close();
            new FileOutputStream(STUDENT_REGISTERATION_FILE, true).close();
            new FileOutputStream(FOUND_ITEMS_FILE, true).close();
            new FileOutputStream(HISTORY_AND_LOG_FILE, true).close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Error initializing file streams", e);
        }
    }

    private void readAllData() {
        readStudentRegistrationData();
        readAdminRegistrationData();
        readFoundItemsData();
        readHistoryAndLogData();
    }

    // Method to check if a file is empty
    private boolean isFileEmpty(String fileName) {
        File file = new File(fileName);
        return file.length() == 0;
    }

    // Methods to read and write student registration data
    public void writeStudentRegistrationData() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(STUDENT_REGISTERATION_FILE))) {
            outputStream.writeObject(student_registeration_log);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public void readStudentRegistrationData() {
        if (!isFileEmpty(STUDENT_REGISTERATION_FILE)) {
            try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(STUDENT_REGISTERATION_FILE))) {
                student_registeration_log = (ArrayList<StudentAccount>) inputStream.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    // Methods to read and write admin registration data
    public void writeAdminRegistrationData() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(ADMIN_REGISTERATION_FILE))) {
            outputStream.writeObject(admin_registeration);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readAdminRegistrationData() {
        if (!isFileEmpty(ADMIN_REGISTERATION_FILE)) {
            try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(ADMIN_REGISTERATION_FILE))) {
                admin_registeration = (Account) inputStream.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    // Methods to read and write found items data
    public void writeFoundItemsData() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(FOUND_ITEMS_FILE))) {
            outputStream.writeObject(found_items);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public void readFoundItemsData() {
        if (!isFileEmpty(FOUND_ITEMS_FILE)) {
            try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(FOUND_ITEMS_FILE))) {
                found_items = (ArrayList<Student>) inputStream.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    // Methods to read and write history and log data
    public void writeHistoryAndLogData() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(HISTORY_AND_LOG_FILE))) {
            outputStream.writeObject(history_and_log);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public void readHistoryAndLogData() {
        if (!isFileEmpty(HISTORY_AND_LOG_FILE)) {
            try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(HISTORY_AND_LOG_FILE))) {
                history_and_log = (ArrayList<Student>) inputStream.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    // Student module related methods
    public boolean registerStudent(String student_id, String student_password, String student_name, String student_age, String student_gender, String student_semester) {
        for (StudentAccount value : student_registeration_log) {
            if (value.getId().equalsIgnoreCase(student_id)) {
                System.out.println("Username already Taken!");
                showAlert("Failed!", "Username already Taken!");
                return false;
            }
        }
        student_registeration_log.add(new StudentAccount(student_id, student_password, student_name, student_age, student_gender, student_semester));
        writeStudentRegistrationData();
        return true;
    }

    public boolean loginStudent(String student_id, String student_password) {
        for (StudentAccount account : student_registeration_log) {
            if (account.getId().equalsIgnoreCase(student_id) && account.getPassword().equals(student_password)) {
                return true;
            }
        }
        System.out.println("\nAccount Not Present!");
        showAlert("Failed!", "Account Not Present!");
        return false;
    }

    public boolean changePassword(String student_id, String student_password, String new_student_password) {
        for (Account account : student_registeration_log) {
            if (account.getId().equalsIgnoreCase(student_id) && account.getPassword().equals(student_password)) {
                account.setPassword(new_student_password);
                System.out.println("\nPassword Changed!");
                showAlert("Success!", "Password Changed Successfully!");
                writeStudentRegistrationData();
                return true;
            }
        }
        System.out.println("\nAccount Not Found!");
        return false;
    }

    public void addFoundItem(String student_id, String student_name, String item_image, String item_name, String item_category, String item_color, String item_location, String item_description) {
        found_items.add(new Student(student_id, student_name, new Item(item_image, item_name, item_category, item_color, item_location, item_description)));
        writeFoundItemsData();
    }

    public void findingOwner(String student_id, String student_name, String item_image, String item_name, String item_category, String item_color, String item_location, String item_description) {
        boolean status = false;
        for (int i = 0; i < found_items.size(); i++) {
            Student foundItem = found_items.get(i);
            if (foundItem.getItem().getItem_name().equalsIgnoreCase(item_name) &&
                    foundItem.getItem().getItem_category().equalsIgnoreCase(item_category) &&
                    foundItem.getItem().getItem_color().equalsIgnoreCase(item_color) &&
                    foundItem.getItem().getItem_location().equalsIgnoreCase(item_location)) {

                double similarity = imageComparator.compareImages(Encryption.decrypt(foundItem.getItem().getItem_image()), Encryption.decrypt(item_image));
                if (similarity >= 70) {
                    status = true;
                    System.out.println("Item Found! Take the items from CUI Lost and Found Department");
                    history_and_log.add(new Student(student_id, student_name, new Item(item_image, item_name, item_category, item_color, item_location, item_description)));
                    found_items.remove(i);
                    writeHistoryAndLogData();
                    writeFoundItemsData();
                    break;
                }
            }
        }
        if (!status) {
            System.out.println("Item not found!");
        }
    }

    // Admin module related methods
    public void registerAdmin(String admin_id, String admin_password) {
        if (admin_registeration instanceof Account) {
            System.out.println("\nAdmin Account Already Present!");
            showAlert("Failed!", "Admin Account Already Present!");
        } else {
            admin_registeration = new Account(admin_id, admin_password);
            writeAdminRegistrationData();
        }
    }

    public boolean loginAdmin(String admin_id, String admin_password) {
        if (admin_registeration instanceof Account &&
                admin_registeration.getId().equalsIgnoreCase(admin_id) &&
                admin_registeration.getPassword().equals(admin_password)) {
            return true;
        }
        showAlert("Failed!", "Admin Account Not Found!");
        System.out.println("\nAdmin Account Not Found!");
        return false;
    }

    // Method to display alert messages
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    public boolean deactivateStudentAccount(String student_id) {

        for (int i = 0; i < student_registeration_log.size(); i++) {

            if (student_registeration_log.get(i).getId().equalsIgnoreCase(student_id)) {
                student_registeration_log.remove(i);
                showAlert("Success!", "Student Account Deactivated!");
                System.out.println("Student Account Deactivated!");
                writeStudentRegistrationData();
                return true;
            }

        }

        System.out.println("Account Not Present!");
        showAlert("Failed!", "Account Not Present!");


        return false;
    }

    public void displayHistoryAndLog(Stage stage, Button backButton) {

        Text title = new Text("History and Log (" + history_and_log.size() + ")");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));
        VBox layout = new VBox(20, title);
        layout.setAlignment(Pos.CENTER); // Center the content vertically

        int i = 1;

        for (Student value : history_and_log) {
            Label newLabel = new Label("<----------------Item #" + i + "---------------->");

            Label newLabel0 = new Label("Owner Name: " + Encryption.decrypt(value.getStudent_name()));
            Label newLabel1 = new Label("Owner Id: " + Encryption.decrypt(value.getStudent_id()));
            Label newLabel2 = new Label("Item Name: " + Encryption.decrypt(value.getItem().getItem_name()));
            Label newLabel3 = new Label("Item Category: " + Encryption.decrypt(value.getItem().getItem_category()));


            newLabel.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel0.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel1.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel2.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel3.setFont(Font.font("Arial", FontWeight.BOLD, 15));

            // Load and display image
            String imagePath = Paths.get("images/" + Encryption.decrypt(value.getItem().getItem_image())).toUri().toString();
            ImageView imageView = new ImageView(new Image(imagePath));
            imageView.setFitWidth(100); // Set width of the image
            imageView.setFitHeight(100); // Set height of the image

            layout.getChildren().addAll(newLabel, imageView, newLabel0, newLabel1, newLabel2, newLabel3);

            System.out.println();
            System.out.println("Owner Name: " + Encryption.decrypt(value.getStudent_name()));
            System.out.println("Owner Id: " + Encryption.decrypt(value.getStudent_id()));
            System.out.println("Item Name: " + Encryption.decrypt(value.getItem().getItem_name()));
            System.out.println("Item Category: " + Encryption.decrypt(value.getItem().getItem_category()));
            i++;
        }


        // Create a layout

        // Wrap the VBox inside a ScrollPane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        // Center the back button
        HBox backButtonContainer = new HBox(backButton);
        backButtonContainer.setAlignment(Pos.CENTER);
        backButtonContainer.setPadding(new Insets(20)); // Add padding if needed

        VBox mainLayout = new VBox(10, scrollPane, backButtonContainer); // Add some spacing between scrollPane and backButton
        mainLayout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(mainLayout, 600, 600);
        stage.setScene(scene);


    }

    public void displayHistoryAndLogEncrypted(Stage stage, Button backButton) {
        Text title = new Text("History and Log (" + history_and_log.size() + ")");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("red"));

        VBox layout = new VBox(20, title);
        layout.setAlignment(Pos.CENTER); // Center the content vertically

        int i = 1;

        for (Student value : history_and_log) {
            Label newLabel = new Label("<----------------Item #" + i + "---------------->");
            Label newLabel0 = new Label("Owner Name: " + value.getStudent_name());
            Label newLabel1 = new Label("Owner Id: " + value.getStudent_id());
            Label newLabel2 = new Label("Item Name: " + value.getItem().getItem_name());
            Label newLabel3 = new Label("Item Category: " + value.getItem().getItem_category());

            newLabel.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel0.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel1.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel2.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel3.setFont(Font.font("Arial", FontWeight.BOLD, 15));

            // Load and display image
            String imagePath = Paths.get("images/" + Encryption.decrypt(value.getItem().getItem_image())).toUri().toString();
            ImageView imageView = new ImageView(new Image(imagePath));
            imageView.setFitWidth(100); // Set width of the image
            imageView.setFitHeight(100); // Set height of the image

            layout.getChildren().addAll(newLabel, imageView, newLabel0, newLabel1, newLabel2, newLabel3);

            System.out.println();
            System.out.println("Owner Name: " + value.getStudent_name());
            System.out.println("Owner Id: " + value.getStudent_id());
            System.out.println("Item Image: " + imagePath);
            System.out.println("Item Name: " + value.getItem().getItem_name());
            System.out.println("Item Category: " + value.getItem().getItem_category());
            i++;
        }

        // Wrap the VBox inside a ScrollPane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        // Center the back button
        HBox backButtonContainer = new HBox(backButton);
        backButtonContainer.setAlignment(Pos.CENTER);
        backButtonContainer.setPadding(new Insets(20)); // Add padding if needed

        VBox mainLayout = new VBox(10, scrollPane, backButtonContainer); // Add some spacing between scrollPane and backButton
        mainLayout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(mainLayout, 600, 600);
        stage.setScene(scene);
    }


    public void displayFoundItems(Stage stage, Button backButton) {
        int i = 1;


        Text title = new Text("Found Items Box (" + found_items.size() + ")");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.setFill(Color.web("#2c3e50"));

        VBox layout = new VBox(20, title);
        layout.setAlignment(Pos.CENTER); // Center the content vertically


        for (Student value : found_items) {
            Label newLabel = new Label("<----------------Item #" + i + "---------------->");
            Label newLabel0 = new Label("Finder Name: " + Encryption.decrypt(value.getStudent_name()));
            Label newLabel1 = new Label("Finder Id: " + Encryption.decrypt(value.getStudent_id()));
            Label newLabel2 = new Label("Item Name: " + Encryption.decrypt(value.getItem().getItem_name()));
            Label newLabel3 = new Label("Item Category: " + Encryption.decrypt(value.getItem().getItem_category()));

            newLabel.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel0.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel1.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel2.setFont(Font.font("Arial", FontWeight.BOLD, 15));
            newLabel3.setFont(Font.font("Arial", FontWeight.BOLD, 15));

            // Load and display image
            String imagePath = Paths.get("images/" + Encryption.decrypt(value.getItem().getItem_image())).toUri().toString();
            ImageView imageView = new ImageView(new Image(imagePath));
            imageView.setFitWidth(100); // Set width of the image
            imageView.setFitHeight(100); // Set height of the image

            layout.getChildren().addAll(newLabel, imageView, newLabel0, newLabel1, newLabel2, newLabel3);

            System.out.println();
            System.out.println("Finder Name: " + Encryption.decrypt(value.getStudent_name()));
            System.out.println("Finder Id: " + Encryption.decrypt(value.getStudent_id()));
            System.out.println("Item Name: " + Encryption.decrypt(value.getItem().getItem_name()));
            System.out.println("Item Category: " + Encryption.decrypt(value.getItem().getItem_category()));

            i++;
        }

        // Wrap the VBox inside a ScrollPane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        // Center the back button
        HBox backButtonContainer = new HBox(backButton);
        backButtonContainer.setAlignment(Pos.CENTER);
        backButtonContainer.setPadding(new Insets(20)); // Add padding if needed

        VBox mainLayout = new VBox(10, scrollPane, backButtonContainer); // Add some spacing between scrollPane and backButton
        mainLayout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(mainLayout, 600, 600);


        stage.setScene(scene);
    }


    public String getStudentPassword(String student_id) {

        String password = null;

        for (Account account : student_registeration_log) {
            if (account.getId().equalsIgnoreCase(student_id)) {
                password = account.getPassword();

            }
        }

        return Encryption.decrypt(password);
    }

}
