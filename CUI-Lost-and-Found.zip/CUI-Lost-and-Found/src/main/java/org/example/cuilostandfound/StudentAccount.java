package org.example.cuilostandfound;

import java.io.Serializable;

public class StudentAccount extends Account implements Serializable {

    private String student_name;
    private String student_age;

    private String student_gender;
    private String student_semester;

    public StudentAccount(String id, String password, String student_name, String student_age, String student_gender, String student_semester) {
        super(id, password);
        this.student_name = student_name;
        this.student_age = student_age;
        this.student_gender = student_gender;
        this.student_semester = student_semester;
    }

    public String getStudent_name() {
        return student_name;
    }
}
